StroopTask.m is a function that can be called in MatLab with 2 inputs as:

StroopTask('name',num)

Name is name of participant and num is number of tasks (how many words presented).

A csv file is created by this function into the same directory with the naming
scheme nameMMDDHHMM.csv